# নিউ সাহানাজ জুয়েলার্স | NEW SAHANAZ JEWELLERS
## Complete Native Android 16 (API 36) Jetpack Compose Project

This archive contains the **100% complete, fully buildable Android Studio project**.

### Project Structure Checklist:
- [x] `settings.gradle.kts` (Root settings with Google & MavenCentral repos)
- [x] `build.gradle.kts` (Root build script with Android & Kotlin 2.0 plugins)
- [x] `gradle.properties` (JVM args & AndroidX configurations)
- [x] `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.9 distribution)
- [x] `gradlew` & `gradlew.bat` (POSIX & Windows wrapper scripts)
- [x] `app/build.gradle.kts` (Targeting Android 16 API 36, Compose BOM, Material 3)
- [x] `app/proguard-rules.pro` (ProGuard rules)
- [x] `app/src/main/AndroidManifest.xml` (Application config & orientation)
- [x] `app/src/main/java/com/newsahanaz/jewellers/MainActivity.kt` (Edge-to-edge Compose)
- [x] `app/src/main/java/com/newsahanaz/jewellers/model/GoldCalculation.kt` (Complete logic)
- [x] `app/src/main/java/com/newsahanaz/jewellers/viewmodel/GoldHisabViewModel.kt` (State & storage)
- [x] `app/src/main/java/com/newsahanaz/jewellers/ui/screens/GoldHisabScreen.kt` (Compose UI)
- [x] `app/src/main/java/com/newsahanaz/jewellers/ui/theme/` (Obsidian & 24K Gold luxury theme)
- [x] `app/src/main/res/values/strings.xml` & `values-bn/strings.xml` (Bilingual strings)
- [x] `app/src/main/res/drawable/` & `mipmap-anydpi-v26/` (Vector gold scale icon)

---

### How to Build Your APK in Android Studio:
1. **Extract this ZIP file** on your PC/Mac.
2. Open **Android Studio** (Koala, Ladybug, or Meerkat).
3. Select **File > Open...** and choose the extracted `NewSahanazJewellers` folder.
4. Android Studio will automatically download the Gradle 8.9 wrapper and sync the dependencies.
5. To generate the APK:
   - Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**
   - Or open the terminal inside Android Studio and run:
     ```bash
     ./gradlew assembleRelease
     ```
     (On Windows: `gradlew.bat assembleRelease`)
6. Your installable APK will be generated at:
