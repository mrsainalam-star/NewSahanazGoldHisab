package com.newsahanaz.jewellers.model

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID

data class WeightInput(
    val bhori: Double = 0.0,
    val ana: Double = 0.0,
    val rati: Double = 0.0,
    val point: Double = 0.0,
    val grams: Double = 0.0
)

data class CustomerDetails(
    val fullName: String = "",
    val phone: String = "",
    val address: String = "",
    val photoBase64: String? = null
)

data class JewelleryPhotoItem(
    val id: String = UUID.randomUUID().toString(),
    val photoBase64: String,
    val description: String = ""
)

data class OldGoldExchangeData(
    val enabled: Boolean = false,
    val weightBhori: Double = 0.0,
    val weightGrams: Double = 0.0,
    val purityCarat: String = "22K",
    val purityPercent: Double = 91.6,
    val deductionPercent: Double = 2.0,
    val buybackRatePerBhori: Double = 0.0,
    val netPureBhori: Double = 0.0,
    val exchangeValue: Double = 0.0
)

data class CalculationResult(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val customer: CustomerDetails = CustomerDetails(),
    val ornamentName: String = "",
    val jewelleryPhotos: List<JewelleryPhotoItem> = emptyList(),
    val totalBhori: Double,
    val totalGrams: Double,
    val goldRatePerBhori: Double,
    val makingChargePerBhori: Double,
    val makingChargePerAna: Double,
    val gstRate: Double,
    val gstEnabled: Boolean,
    val goldPrice: Double,
    val makingCharge: Double,
    val taxableTotal: Double,
    val gstAmount: Double,
    val grandTotal: Double,
    val oldGold: OldGoldExchangeData = OldGoldExchangeData(),
    val oldGoldExchangeValue: Double = 0.0,
    val netPayable: Double
)

object GoldCalculationEngine {
    const val BHORI_IN_ANA = 16.0
    const val ANA_IN_RATI = 6.0
    const val BHORI_IN_RATI = 96.0 // 16 ana * 6 rati
    const val BHORI_IN_POINTS = 9600.0 // 96 rati * 100 points
    const val DEFAULT_BHORI_IN_GRAMS = 11.664

    fun traditionalToBhori(bhori: Double, ana: Double, rati: Double, point: Double): Double {
        return bhori + (ana / BHORI_IN_ANA) + (rati / BHORI_IN_RATI) + (point / BHORI_IN_POINTS)
    }

    fun bhoriToGrams(bhori: Double, conversion: Double = DEFAULT_BHORI_IN_GRAMS): Double {
        return bhori * conversion
    }

    fun gramsToBhori(grams: Double, conversion: Double = DEFAULT_BHORI_IN_GRAMS): Double {
        if (grams <= 0.0) return 0.0
        return grams / conversion
    }

    fun roundCurrency(amount: Double): Double {
        return BigDecimal(amount).setScale(2, RoundingMode.HALF_UP).toDouble()
    }

    fun calculate(
        weightInBhori: Double,
        goldRate: Double,
        makingChargeBhori: Double,
        gstRate: Double,
        gstEnabled: Boolean,
        customer: CustomerDetails = CustomerDetails(),
        ornamentName: String = "",
        photos: List<JewelleryPhotoItem> = emptyList(),
        oldGold: OldGoldExchangeData = OldGoldExchangeData()
    ): CalculationResult {
        val totalGrams = bhoriToGrams(weightInBhori)
        val makingChargeAna = roundCurrency(makingChargeBhori / 16.0)
        val goldPrice = roundCurrency(weightInBhori * goldRate)
        val makingCharge = roundCurrency(weightInBhori * makingChargeBhori)
        val taxableTotal = roundCurrency(goldPrice + makingCharge)
        val gstAmount = if (gstEnabled) roundCurrency(taxableTotal * (gstRate / 100.0)) else 0.0
        val grandTotal = roundCurrency(taxableTotal + gstAmount)

        var oldGoldVal = 0.0
        if (oldGold.enabled && oldGold.weightBhori > 0) {
            val purityFactor = oldGold.purityPercent / 100.0
            val deductionFactor = (100.0 - oldGold.deductionPercent) / 100.0
            val netPure = oldGold.weightBhori * purityFactor * deductionFactor
            val rate = if (oldGold.buybackRatePerBhori > 0) oldGold.buybackRatePerBhori else goldRate
            oldGoldVal = roundCurrency(netPure * rate)
        }

        val netPayable = roundCurrency(grandTotal - oldGoldVal)

        return CalculationResult(
            customer = customer,
            ornamentName = ornamentName,
            jewelleryPhotos = photos,
            totalBhori = weightInBhori,
            totalGrams = totalGrams,
            goldRatePerBhori = goldRate,
            makingChargePerBhori = makingChargeBhori,
            makingChargePerAna = makingChargeAna,
            gstRate = gstRate,
            gstEnabled = gstEnabled,
            goldPrice = goldPrice,
            makingCharge = makingCharge,
            taxableTotal = taxableTotal,
            gstAmount = gstAmount,
            grandTotal = grandTotal,
            oldGold = oldGold.copy(exchangeValue = oldGoldVal),
            oldGoldExchangeValue = oldGoldVal,
            netPayable = netPayable
        )
    }
}
