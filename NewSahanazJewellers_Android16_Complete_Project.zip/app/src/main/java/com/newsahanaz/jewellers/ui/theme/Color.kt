package com.newsahanaz.jewellers.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBlack = Color(0xFF0B0B0C)
val DeepCharcoal = Color(0xFF141316)
val CardElevated = Color(0xFF1C1A20)
val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF7E599)
val GoldAccent = Color(0xFFE5C158)
val GoldBorder = Color(0x40D4AF37)
val TextPrimary = Color(0xFFFBF4DF)
val TextSecondary = Color(0xFFC7BA99)
