package com.newsahanaz.jewellers.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.newsahanaz.jewellers.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ShopSettingsData(
    val shopNameBn: String = "নিউ সাহানাজ জুয়েলার্স",
    val shopNameEn: String = "NEW SAHANAZ JEWELLERS",
    val phone: String = "+91 98765 43210",
    val address: String = "জুয়েলারি বাজার, ভারত (India)",
    val goldRatePerBhori: Double = 92500.0,
    val makingChargePerBhori: Double = 4800.0,
    val makingChargePerAna: Double = 300.0,
    val gstRate: Double = 3.0,
    val gstEnabled: Boolean = true
)

class GoldHisabViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("sahanaz_gold_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<ShopSettingsData> = _settings.asStateFlow()

    private val _weight = MutableStateFlow(WeightInput(bhori = 1.0, grams = 11.664))
    val weight: StateFlow<WeightInput> = _weight.asStateFlow()

    private val _customer = MutableStateFlow(CustomerDetails())
    val customer: StateFlow<CustomerDetails> = _customer.asStateFlow()

    private val _ornamentName = MutableStateFlow("")
    val ornamentName: StateFlow<String> = _ornamentName.asStateFlow()

    private val _photos = MutableStateFlow<List<JewelleryPhotoItem>>(emptyList())
    val photos: StateFlow<List<JewelleryPhotoItem>> = _photos.asStateFlow()

    private val _oldGold = MutableStateFlow(OldGoldExchangeData())
    val oldGold: StateFlow<OldGoldExchangeData> = _oldGold.asStateFlow()

    private val _history = MutableStateFlow<List<CalculationResult>>(loadHistory())
    val history: StateFlow<List<CalculationResult>> = _history.asStateFlow()

    fun updateGoldRate(rate: Double) {
        val s = _settings.value.copy(goldRatePerBhori = rate)
        _settings.value = s
        saveSettings(s)
    }

    fun updateMakingChargePerAna(anaRate: Double) {
        val bhoriRate = anaRate * 16.0
        val s = _settings.value.copy(makingChargePerAna = anaRate, makingChargePerBhori = bhoriRate)
        _settings.value = s
        saveSettings(s)
    }

    fun updateGst(enabled: Boolean, rate: Double) {
        val s = _settings.value.copy(gstEnabled = enabled, gstRate = rate)
        _settings.value = s
        saveSettings(s)
    }

    fun updateWeight(bhori: Double, ana: Double, rati: Double, point: Double) {
        val totalB = GoldCalculationEngine.traditionalToBhori(bhori, ana, rati, point)
        val grams = GoldCalculationEngine.bhoriToGrams(totalB)
        _weight.value = WeightInput(bhori, ana, rati, point, grams)
    }

    fun updateWeightFromGrams(grams: Double) {
        val totalB = GoldCalculationEngine.gramsToBhori(grams)
        _weight.value = WeightInput(bhori = totalB, grams = grams)
    }

    fun updateCustomer(name: String, phone: String, address: String) {
        _customer.value = _customer.value.copy(fullName = name, phone = phone, address = address)
    }

    fun setCustomerPhoto(base64: String?) {
        _customer.value = _customer.value.copy(photoBase64 = base64)
    }

    fun addJewelleryPhoto(photo: JewelleryPhotoItem) {
        _photos.value = _photos.value + photo
    }

    fun removeJewelleryPhoto(id: String) {
        _photos.value = _photos.value.filter { it.id != id }
    }

    fun updateOldGold(updated: OldGoldExchangeData) {
        _oldGold.value = updated
    }

    fun saveCurrentCalculation(calc: CalculationResult) {
        val list = listOf(calc) + _history.value.filter { it.id != calc.id }
        _history.value = list.take(100)
        prefs.edit().putString("calc_history", gson.toJson(_history.value)).apply()
    }

    fun deleteHistoryItem(id: String) {
        val list = _history.value.filter { it.id != id }
        _history.value = list
        prefs.edit().putString("calc_history", gson.toJson(list)).apply()
    }

    private fun loadSettings(): ShopSettingsData {
        val json = prefs.getString("shop_settings", null) ?: return ShopSettingsData()
        return try {
            gson.fromJson(json, ShopSettingsData::class.java)
        } catch (e: Exception) {
            ShopSettingsData()
        }
    }

    private fun saveSettings(s: ShopSettingsData) {
        prefs.edit().putString("shop_settings", gson.toJson(s)).apply()
    }

    private fun loadHistory(): List<CalculationResult> {
        val json = prefs.getString("calc_history", null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<CalculationResult>>() {}.type
            gson.fromJson(json, type)
        } catch (e: Exception) {
            emptyList()
        }
    }
}
