package com.newsahanaz.jewellers.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.newsahanaz.jewellers.model.GoldCalculationEngine
import com.newsahanaz.jewellers.ui.theme.*
import com.newsahanaz.jewellers.viewmodel.GoldHisabViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoldHisabMainScreen(viewModel: GoldHisabViewModel) {
    val settings by viewModel.settings.collectAsState()
    val weight by viewModel.weight.collectAsState()
    val customer by viewModel.customer.collectAsState()
    val ornamentName by viewModel.ornamentName.collectAsState()
    val photos by viewModel.photos.collectAsState()
    val oldGold by viewModel.oldGold.collectAsState()

    val currentCalc = remember(settings, weight, customer, ornamentName, photos, oldGold) {
        val totalB = if (weight.bhori > 0) weight.bhori else GoldCalculationEngine.gramsToBhori(weight.grams)
        GoldCalculationEngine.calculate(
            weightInBhori = totalB,
            goldRate = settings.goldRatePerBhori,
            makingChargeBhori = settings.makingChargePerBhori,
            gstRate = settings.gstRate,
            gstEnabled = settings.gstEnabled,
            customer = customer,
            ornamentName = ornamentName,
            photos = photos,
            oldGold = oldGold
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "নিউ সাহানাজ জুয়েলার্স",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary
                            )
                        )
                        Text(
                            text = "NEW SAHANAZ JEWELLERS • 100% BIS Hallmarked",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianBlack,
                    titleContentColor = GoldLight
                )
            )
        },
        containerColor = ObsidianBlack
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Rates Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, GoldBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = CardElevated)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("সোনার দর ও মজুরি (Rate & Making)", fontWeight = FontWeight.Bold, color = GoldLight)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("দর/ভরি: ₹${settings.goldRatePerBhori.toInt()}", color = TextPrimary)
                            Text("মজুরি/আনা: ₹${settings.makingChargePerAna.toInt()}", color = GoldAccent)
                        }
                    }
                }
            }

            // Weight Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, GoldBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = CardElevated)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("স্বর্ণের ওজন (Weight)", fontWeight = FontWeight.Bold, color = GoldLight)
                        Text("মোট ভরি: ${String.format("%.4f", currentCalc.totalBhori)} ভরি | ${String.format("%.3f", currentCalc.totalGrams)} গ্রাম", color = TextPrimary)
                    }
                }
            }

            // Summary & Grand Total Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(2.dp, GoldPrimary, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = DeepCharcoal)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (oldGold.enabled && currentCalc.oldGoldExchangeValue > 0) "অবশিষ্ট প্রদেয় নগদ (Net Payable)" else "সর্বমোট প্রদেয় টাকা (Grand Total)",
                            style = MaterialTheme.typography.labelMedium,
                            color = GoldPrimary
                        )
                        Text(
                            text = "₹${String.format("%,.2f", if (oldGold.enabled && currentCalc.oldGoldExchangeValue > 0) currentCalc.netPayable else currentCalc.grandTotal)}",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = GoldLight
                            )
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("সোনার দাম: ₹${String.format("%,.2f", currentCalc.goldPrice)}", fontSize = 12.sp, color = TextSecondary)
                            Text("মজুরি: ₹${String.format("%,.2f", currentCalc.makingCharge)}", fontSize = 12.sp, color = TextSecondary)
                        }
                    }
                }
            }
        }
    }
}
