package com.newsahanaz.jewellers

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.newsahanaz.jewellers.ui.screens.GoldHisabMainScreen
import com.newsahanaz.jewellers.ui.theme.NewSahanazJewellersTheme
import com.newsahanaz.jewellers.viewmodel.GoldHisabViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Android 16 Edge-to-Edge System Bar Integration
        enableEdgeToEdge()

        setContent {
            NewSahanazJewellersTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val viewModel: GoldHisabViewModel = viewModel()
                    GoldHisabMainScreen(viewModel = viewModel)
                }
            }
        }
    }
}
