# Project-specific ProGuard rules
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* *;
}
